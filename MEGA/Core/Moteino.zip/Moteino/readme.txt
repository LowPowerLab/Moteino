Copy the "Moteino" folder and all its contents in your Arduino installation "Hardware" folder.

After copying the path the the boards.txt file should look like this:
    [drive/path]/Arduino/Hardware/Moteino/avr/boards.txt

Then restart the Arduino IDE and under "Tools > Boards" you should have 2 new entries: Moteino, MoteinoMEGA.
This was tested and is supported on Arduino IDE v1.6.1, please upgrade to this version to use this core.

This guide was used to adapt the older 1.0.6 version of this core to work with Arduino 1.6.1:
https://github.com/arduino/Arduino/wiki/Arduino-Hardware-Cores-migration-guide-from-1.0-to-1.6